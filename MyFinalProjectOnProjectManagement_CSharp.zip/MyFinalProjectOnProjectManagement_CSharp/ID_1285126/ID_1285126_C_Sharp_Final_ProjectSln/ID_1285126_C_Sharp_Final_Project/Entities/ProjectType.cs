﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ID_1285126_C_Sharp_Final_Project.Entities
{
    public enum ProjectType
    {
         LongTermProject=1, ShortTermProject
    }
    public enum Department
    {
        IT = 1, HR = 2, PayRoll, Sales, Networking,Accounts,Others=0

    }

}
