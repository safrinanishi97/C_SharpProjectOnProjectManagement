﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ID_1285126_C_Sharp_Final_Project.Manager
{
    public class ShortTermProjectManager : IProjectManager
    {

        public double GetProfit()
        {
            double profitPcnt = .5;
            double profit = profitPcnt * ProjectBudget();
            return profit;
        }

        public double ProjectBudget()
        {
            double budget = 200000;
            return budget;
        }
        public double Expenditure()
        {
            double othersExpensePcnt = 0.2;
            double totalExpense = ProjectBudget() + (ProjectBudget() * othersExpensePcnt);
            return totalExpense;
        }
        public double MonitoringTeamMember()
        {
            return 0;
        }

        public string FacilitiesAndDrawBack()
        {
            return ("Temporary and flexible");
        }
    }
}
