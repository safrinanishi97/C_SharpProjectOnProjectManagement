﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ID_1285126_C_Sharp_Final_Project.Manager
{
    public class LongTermProjectManager : IProjectManager
    {
        public double GetProfit()
        {
            double profitPcnt = .7;
            double profit = profitPcnt * ProjectBudget();
            return profit;
        }

        public double ProjectBudget()
        {
            double budget = 500000;
            return budget;
        }
        public double Expenditure()
        {
            double othersExpensePcnt = 0.3;
            double totalExpense = ProjectBudget() + (ProjectBudget() * othersExpensePcnt);
            return totalExpense;
        }

        public double MonitoringTeamMember()
        {
            return 4;

        }


        public string FacilitiesAndDrawBack()
        {
            return ("Inflexible, overwhelming and longlasting");
        }
    }
}
